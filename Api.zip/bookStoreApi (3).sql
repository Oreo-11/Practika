-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 22 2022 г., 09:36
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `bookStoreApi`
--

-- --------------------------------------------------------

--
-- Структура таблицы `author`
--

CREATE TABLE `author` (
  `id_author` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `author`
--

INSERT INTO `author` (`id_author`, `name`) VALUES
(25, 'Сара Дж. Маас'),
(28, 'Ода Э.'),
(37, 'Кэнтаро Миура'),
(38, 'Анджей Сапковский');

-- --------------------------------------------------------

--
-- Структура таблицы `books`
--

CREATE TABLE `books` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` double NOT NULL,
  `date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discription` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `books`
--

INSERT INTO `books` (`id`, `name`, `image`, `rate`, `date`, `discription`) VALUES
(63, 'One Piece. Большой куш. Книга 11...', '2950584_detail.jpg', 5, '2007', 'Голд Роджер – король пиратов, добившийся за свою жизнь богатства, славы и власти, спрятал где-то на просторах этого мира загадочное сокровище, которое все называют «One Piece». После смерти Роджера множество смельчаков кинулись на поиски этого большого куша. И наступила великая эпоха пиратов!\r\nВот и паренек по имени Луффи, живущий в маленькой прибрежной деревушке, мечтает стать пиратом. Еще в детстве он ненароком съел плод резина-резина и приобрел невероятные способности. Повзрослев, он покидает родные места в погоне за величайшим сокровищем!'),
(64, 'One Piece. Большой куш. Книга 7...', '2929771_detail.jpg', 5, '2008', 'Голд Роджер – король пиратов, добившийся за свою жизнь богатства, славы и власти, спрятал где-то на просторах этого мира загадочное сокровище, которое все называют «One Piece». После смерти Роджера множество смельчаков кинулись на поиски этого большого куша. И наступила великая эпоха пиратов!\r\nВот и паренек по имени Луффи, живущий в маленькой прибрежной деревушке, мечтает стать пиратом. Еще в детстве он ненароком съел плод резина-резина и приобрел невероятные способности. Повзрослев, он покидает родные места в погоне за величайшим сокровищем!'),
(65, 'Ведьмак', '63789a34a1c4b.jpg', 4, '2020', 'Одна из лучших фэнтези-саг за всю историю существования жанра. Оригинальное, масштабное эпическое произведение, одновременно и свободное от влияния извне, и связанное с классической мифологической, легендарной и сказовой традицией. Шедевр не только писательского мастерства Анджея Сапковского, но и переводческого искусства Евгения Павловича Вайсброта. \"Сага о Геральте\" - в одном томе. Бесценный подарок и для поклонника прекрасной фантастики, и для ценителя просто хорошей литературы. Перед читателем буквально оживает необычный, прекрасный и жестокий мир литературной легенды, в котором обитают эльфы и гномы, оборотни, вампиры и \"низушки\"-хоббиты, драконы и монстры, - но прежде всего ЛЮДИ.\r\nОчень близкие нам, понятные и человечные люди - такие как мастер меча ведьмак Геральт, его друг, беспутный менестрель Лютик, его возлюбленная, прекрасная чародейка Йеннифэр, и приемная дочь - безрассудно отважная юная Цири…'),
(66, 'королевство шипов  и роз', '2817887_detail.jpg', 5, '2020', 'Могла ли знать девятнадцатилетняя Фейра, что огромный волк, убитый девушкой на охоте, — на самом деле преображенный фэйри. Расплата не заставила себя ждать. Она должна или заплатить жизнью, или переселиться за стену — волшебную невидимую преграду, отделяющую владения смертных от Притиании, королевства фэйри. Фейра выбирает второе. Тамлин, владелец замка, куда девушка попадает, не простой фэйри, он — верховный правитель Двора весны, одного из могущественных Дворов, на которые поделено королевство. Однажды Фейра узнает тайну: на Двор весны и на Тамлина, ее покровителя, злые силы наложили заклятье, снять которое способна только смертная девушка…'),
(67, 'Токийские Мстители. Том 3', '637b9a9479bc6.jpg', 4, '2022', 'Узнав, что спасение Дракэна не поможет изменить будущее, Такэмити решает стать президентом 3-го отделения ТГМ. Однако на ближайшей сходке выясняется, что президентом назначен Тэтта Кисаки, худший кандидат из возможных. Именно к нему ведут все ниточки, он определенно как-то связан с «Мёбиусом» и новой группировкой «Вальгалла», которая планирует разгромить ТГМ. Вдобавок из ТГМ уходит один из основателей — Кэйскэ Бадзи, и его потеря обещает катастрофические последствия...');

-- --------------------------------------------------------

--
-- Структура таблицы `books_author`
--

CREATE TABLE `books_author` (
  `id` int NOT NULL,
  `id_book` int NOT NULL,
  `id_author` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `books_author`
--

INSERT INTO `books_author` (`id`, `id_book`, `id_author`) VALUES
(62, 67, 37),
(66, 66, 25),
(70, 65, 38),
(71, 64, 28),
(72, 63, 28);

-- --------------------------------------------------------

--
-- Структура таблицы `books_genres`
--

CREATE TABLE `books_genres` (
  `id` int NOT NULL,
  `id_book` int NOT NULL,
  `id_genre` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `books_genres`
--

INSERT INTO `books_genres` (`id`, `id_book`, `id_genre`) VALUES
(35, 67, 4),
(39, 66, 1),
(43, 65, 1),
(44, 64, 3),
(45, 63, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `genres`
--

CREATE TABLE `genres` (
  `id_genres` int NOT NULL,
  `genre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `genres`
--

INSERT INTO `genres` (`id_genres`, `genre`) VALUES
(1, 'Фэнтэзи'),
(2, 'Научная фантастика'),
(3, 'Манга'),
(4, 'Боевик'),
(5, 'Триллер/Ужасы'),
(6, 'Мистика'),
(7, 'Детектив');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`id_author`);

--
-- Индексы таблицы `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `books_author`
--
ALTER TABLE `books_author`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_author` (`id_author`),
  ADD KEY `id_book` (`id_book`);

--
-- Индексы таблицы `books_genres`
--
ALTER TABLE `books_genres`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_book` (`id_book`),
  ADD KEY `id_genre` (`id_genre`);

--
-- Индексы таблицы `genres`
--
ALTER TABLE `genres`
  ADD PRIMARY KEY (`id_genres`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `author`
--
ALTER TABLE `author`
  MODIFY `id_author` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT для таблицы `books`
--
ALTER TABLE `books`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT для таблицы `books_author`
--
ALTER TABLE `books_author`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT для таблицы `books_genres`
--
ALTER TABLE `books_genres`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT для таблицы `genres`
--
ALTER TABLE `genres`
  MODIFY `id_genres` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `books_author`
--
ALTER TABLE `books_author`
  ADD CONSTRAINT `books_author_ibfk_1` FOREIGN KEY (`id_author`) REFERENCES `author` (`id_author`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `books_author_ibfk_2` FOREIGN KEY (`id_book`) REFERENCES `books` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `books_genres`
--
ALTER TABLE `books_genres`
  ADD CONSTRAINT `books_genres_ibfk_1` FOREIGN KEY (`id_book`) REFERENCES `books` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `books_genres_ibfk_2` FOREIGN KEY (`id_genre`) REFERENCES `genres` (`id_genres`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
